<?php 
 
$server = "localhost";
$user = "bangkit";
$pass = "santai123";
$database = "nowsms";
 
$conn = mysqli_connect($server, $user, $pass, $database);
 
if (!$conn) {
    die("<script>alert('Gagal tersambung dengan database.')</script>");
}
 
?>