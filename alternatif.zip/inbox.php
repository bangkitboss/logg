<!DOCTYPE html>
<html>
<head>
	<title>All Inbox</title>
	<link rel="stylesheet" type="text/css" href="text.css">
</head>
<body>
<div class="container">
	<h1>Inbox</h1>
	<table class="highlighted-row">
		<thead>
			<tr>
				<th>NO</th>
				<th>PENGIRIM</th>
				<th>TEXT</th>
			</tr>
		</thead>
		<tbody>
			<?php 
			include 'db.php';
			$no = 1;
			$data = mysqli_query($conn,"select * from inbox");
			while($d = mysqli_fetch_array($data)){
				?>
				<tr>
					<td><?php echo $no++; ?></td>
					<td><?php echo $d['sender']; ?></td>
					<td><?php echo $d['isi']; ?></td>
				</tr>
				<?php 
			}
			?>
		</tbody>
	</table>
</div>
<div class="input-group">
<a href="logout.php" class="btn">Logout</a>
</div>
</body>
</html>